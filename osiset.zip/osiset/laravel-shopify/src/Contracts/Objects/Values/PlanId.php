<?php

namespace Osiset\ShopifyApp\Contracts\Objects\Values;

use Funeralzone\ValueObjects\ValueObject;

/**
 * Plan's ID value object.
 */
interface PlanId extends ValueObject
{
}
